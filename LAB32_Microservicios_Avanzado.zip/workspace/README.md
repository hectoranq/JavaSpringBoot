﻿# Workspace Microservicios Avanzado
 ## Instroduccion
 
 ```
    Este conjunto de proyectos, corresponden a los ejercicios del curso Microservicios Nivel Avanzado.
    para ejecutarlos tienes que clonar el repositorio y cargarlos en Spring Tool Suite
 ```
 
 ## springboot-servicio-productos
 ```
    La solucion del lab 2 corresponde al proyecto inicial springboot-servicio-productos. Este proyecto
    cambiara en la medida que se van realizando los proximos laboratorios.
 ```
 ## springboot-servicio-items
 ```
    La solucion del lab 3 corresponde al proyecto inicial springboot-servicio-items. Este proyecto
    cambiara en la medida que se van realizando los proximos laboratorios. Este proyecto implementa
    un cliente Rest del servicio springboot-servicio-productos, esta primera implementacion es una
    version basica, en los sucesivos laboratiores estaremos desarrollando los servicios del ecosistema
    y la version cambiara hacia una version flexible utilizando servicios de plataforma.
 ```
## springboot-servicio-eureka-server
 ```
    La solucion del parcial del lab 7 corresponde al proyecto inicial springboot-servicio-eureka-server.
    Este proyecto corresponde a la implementacion de un servicio base o de plataforma, especificamente
    utilizaremos Eureka como servicio de registro de servicios.
 ```
