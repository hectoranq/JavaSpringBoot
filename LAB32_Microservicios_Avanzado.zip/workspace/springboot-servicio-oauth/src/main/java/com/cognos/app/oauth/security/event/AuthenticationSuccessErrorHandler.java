package com.cognos.app.oauth.security.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationEventPublisher;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import com.cognos.app.oauth.service.IUsuarioService;
import com.cognos.app.usuarios.commons.model.entity.Usuario;

import feign.FeignException;

@Component
public class AuthenticationSuccessErrorHandler implements AuthenticationEventPublisher {

	private Logger log = LoggerFactory.getLogger(AuthenticationSuccessErrorHandler.class);

	@Autowired
	private IUsuarioService usuarioService;

	@Override
	public void publishAuthenticationSuccess(Authentication authentication) {
		UserDetails user = (UserDetails) authentication.getPrincipal();
		String mensaje = "Login Exitoso: " + user.getUsername();
		System.out.println(mensaje);
		log.info(mensaje);
		Usuario usuario = usuarioService.findByUsername(authentication.getName());
		if (usuario.getIntentosLogin() != null && usuario.getIntentosLogin() > 0) {
			usuario.setIntentosLogin(0);
			usuarioService.update(usuario, usuario.getId());
		}

	}

	@Override
	public void publishAuthenticationFailure(AuthenticationException exception, Authentication authentication) {
		String mensaje = "Error de Login: " + exception.getMessage();
		System.out.println(mensaje);
		log.info(mensaje);
		try {
			Usuario usuario = usuarioService.findByUsername(authentication.getName());
			if (usuario.getIntentosLogin() == null) {
				usuario.setIntentosLogin(0);
			}
			usuario.setIntentosLogin(usuario.getIntentosLogin() + 1);
			log.info(String.format("El numero de intentos actual: %s", usuario.getIntentosLogin()));
			if (usuario.getIntentosLogin() >= 3) {
				usuario.setEnabled(false);
				log.error(String.format("El usuario %s deshabilitado supero los intentos posibles",
						usuario.getUsername()));
			}
			usuarioService.update(usuario, usuario.getId());
		} catch (FeignException e) {
			log.error(String.format("El usuario %s no existe.", authentication.getName()));
		}
	}

}
