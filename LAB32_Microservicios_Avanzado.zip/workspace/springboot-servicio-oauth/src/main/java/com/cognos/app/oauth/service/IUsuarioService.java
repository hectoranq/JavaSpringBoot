package com.cognos.app.oauth.service;

import com.cognos.app.usuarios.commons.model.entity.Usuario;

public interface IUsuarioService {

	public Usuario findByUsername(String username);

	public Usuario update(Usuario usuario, Long id);

}
