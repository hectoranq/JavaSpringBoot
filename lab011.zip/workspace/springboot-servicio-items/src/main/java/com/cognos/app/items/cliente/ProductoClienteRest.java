package com.cognos.app.items.cliente;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cognos.app.items.model.Producto;

//@FeignClient(name="servicio-productos",url="http://localhost:8081") 
// No es necesario el parametro url porque Ribbon realizara el balanceo
@FeignClient(name="servicio-productos")
public interface ProductoClienteRest {
	
	@GetMapping("/listar")  
	public List<Producto> listar();   
	
	@GetMapping("/mostrar/{id}")  
	public Producto mostrar(@PathVariable Long id); 
	
}
