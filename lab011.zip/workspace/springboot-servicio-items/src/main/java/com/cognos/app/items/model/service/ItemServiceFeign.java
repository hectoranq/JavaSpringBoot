package com.cognos.app.items.model.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.cognos.app.items.cliente.ProductoClienteRest;
import com.cognos.app.items.model.Item;

@Service
//@Primary
public class ItemServiceFeign implements ItemService {

	@Autowired  private 
	ProductoClienteRest clienteFeignt; 
	
	@Override
	public List<Item> findAll() {
		return clienteFeignt.listar().stream().map(p -> new Item(p,1)).collect(Collectors.toList()); 
	}

	@Override
	public Item findbyId(Long id, Integer cantidad) {
		return new Item(clienteFeignt.mostrar(id),cantidad); 
	}

}
