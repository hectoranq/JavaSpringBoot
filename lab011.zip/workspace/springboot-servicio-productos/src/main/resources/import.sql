insert into productos (nombre, precio, create_at) values ('Cup', 800, now());
insert into productos (nombre, precio, create_at) values ('TShirt', 500, now());
insert into productos (nombre, precio, create_at) values ('Raquet', 600, now());
insert into productos (nombre, precio, create_at) values ('Balls', 200, now());
