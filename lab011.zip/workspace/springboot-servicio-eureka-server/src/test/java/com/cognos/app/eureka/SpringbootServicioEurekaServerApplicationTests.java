package com.cognos.app.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
