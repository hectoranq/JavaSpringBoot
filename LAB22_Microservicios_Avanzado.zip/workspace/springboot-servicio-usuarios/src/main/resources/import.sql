insert into usuarios (username,password,enabled,nombre,apellido,email) values('carlos','$2a$10$PR4mN139rOdbdyGQJ4kCbeJzQBR05h2XIMAtgFkKyaImTxGum9Niu',1,'Carlos','Carreño','carlos@cognos.com');
insert into usuarios (username,password,enabled,nombre,apellido,email) values('franklin','$2a$10$qsru5gVeP7IclrPdEes23.76Yn568pv7KRCgJUN.81I4V4M6Y03HK',1,'Franklin','Noloc','franklin@cognos.com');

insert into roles (nombre) values('ROLE_USER');
insert into roles (nombre) values('ROLE_ADMIN');

insert into usuarios_roles (usuario_id, role_id) values (1,1);
insert into usuarios_roles (usuario_id, role_id) values (2,2);
insert into usuarios_roles (usuario_id, role_id) values (2,1);