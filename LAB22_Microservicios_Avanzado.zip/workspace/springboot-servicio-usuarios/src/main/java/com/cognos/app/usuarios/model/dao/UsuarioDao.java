package com.cognos.app.usuarios.model.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;

import com.cognos.app.usuarios.commons.model.entity.Usuario;

@RepositoryRestResource(path = "usuarios")
public interface UsuarioDao extends PagingAndSortingRepository<Usuario, Long> {

	/**
	 * Usando palabras clave (ver Spring Data JPA Reference) podemos crear metodos
	 * personalizados, adicionales a los que expone el framework
	 */
	@RestResource(path = "buscar-usuario")
	public Usuario findByUsername(@Param("nombre") String username);

	// JPA-QL
	@Query("Select u From Usuario u where u.username=?1")
	public Usuario obtenerPorUsername(String username);

	// Tambien se puede usar query nativos
	// @Query(value = "SELECT * FROM USERS WHERE EMAIL_ADDRESS = ?1", nativeQuery =
	// true)
}
